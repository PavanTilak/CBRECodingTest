package com.example.codingtestcbre.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utils {

    public static final String BASE_URL = "http://dallas-restaurants.33gfuuywva.us-east-2.elasticbeanstalk.com/";
    public static final String RESTAURANT_LIST_KEY = "RestaurantsList";
    public static final String RESTAURANT_KEY = "Restaurant";

    public static boolean isRestaurantOpen(String openTime , String closeTime) {
        try {
            //Displaying current time in 12 hour format with AM/PM
            SimpleDateFormat dateFormat = new SimpleDateFormat("hhaa");

            Date openDate = dateFormat.parse(openTime);
            Date closeDate = dateFormat.parse(closeTime);
            Date currentDate = dateFormat.parse(dateFormat.format(new Date()));

            System.out.println("  openDate="+openDate +" closeDate="+closeDate +"  currentDate="+currentDate);

            if(currentDate.after(closeDate)){
                //Restaurant closed
                return false;
            }

            if(currentDate.after(openDate) && closeDate.after(currentDate)) {
                return true;
            }

            if(openDate.before(currentDate) || closeDate.after(currentDate)
                || openDate.after(currentDate) || openDate.equals(currentDate)){
                return true;
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return false;
    }
}
