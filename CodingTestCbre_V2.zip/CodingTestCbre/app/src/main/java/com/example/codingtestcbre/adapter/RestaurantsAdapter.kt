package com.example.codingtestcbre.adapter

import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import androidx.recyclerview.widget.RecyclerView

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView


import com.example.codingtestcbre.R
import com.example.codingtestcbre.model.RestaurantsModel
import com.example.codingtestcbre.utils.Utils
import com.example.codingtestcbre.view.RestaurantDetailsScreen
import com.squareup.picasso.Picasso

import java.util.ArrayList

/**
 * "name": "Liberty Burger",
 * "postalCode": "75214",
 * "phoneNumber": "(214) 887-9999",
 * "state": "Texas",
 * "id": "b75862f1-d28a-11e9-b5c9-0a389e6da5d4",
 * "websiteUrl": "https://www.givemelibertyburger.com",
 * "description": "Local chain outpost supplying high-end burgers plus salads & sides in spare but stylish digs.",
 * "category": "Burgers",
 * "city": "Dallas",
 * "longitude": -96.752351,
 * "goodFor": "Comfort food,Outdoor seating,Quick bite",
 * "latitude": 32.813099,
 * "closeTime": "9PM",
 * "streetAddress": "1904 Abrams Pkwy",
 * "openTime": "11AM",
 * "imageUrl": "https://dallas-restaurants.s3.us-east-2.amazonaws.com/fd7b13a2-ce94-11e9-a32f-2a2ae2dbcce4.jpg"
 */
class RestaurantsAdapter(private val mRestaurantList: ArrayList<RestaurantsModel>?, private val context: Context) : RecyclerView.Adapter<RestaurantsAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.restaurant_row, parent, false)

        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val restaurantsModel = mRestaurantList!![position]

        holder.restName.text = restaurantsModel.name
        holder.restCategory.text = restaurantsModel.category
        holder.restGoodFor.text = restaurantsModel.goodFor

        val openTime = restaurantsModel.openTime
        val closeTime = restaurantsModel.closeTime
        if (Utils.isRestaurantOpen(openTime, closeTime)) {
            holder.restOpenClose.text = "Open until $closeTime"
            holder.restOpenClose.setTextColor(context.resources.getColor(R.color.green))
        } else {
            holder.restOpenClose.text = "Closed until tomorrow at $openTime"
            holder.restOpenClose.setTextColor(context.resources.getColor(R.color.red))
        }

        Picasso.get().load(restaurantsModel.imageUrl).into(holder.imageDataView)

        holder.itemView.setOnClickListener {
            //listener for row click

            /*FragmentTransaction ft =  ((FragmentActivity)context).getSupportFragmentManager().beginTransaction();
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
                RestaurantDetailsScreen fragment2 = new RestaurantDetailsScreen();

                Bundle bundle = new Bundle();
                bundle.putSerializable(Utils.RESTAURANT_KEY , mRestaurantList.get(position));
                fragment2.setArguments(bundle);
                ft.replace(android.R.id.content, fragment2);
                //ft.addToBackStack(null);
                ft.commit();*/


            val fragment2 = RestaurantDetailsScreen()
            val ft = (context as FragmentActivity).supportFragmentManager.beginTransaction()
            val bundle = Bundle()
            bundle.putSerializable(Utils.RESTAURANT_KEY, mRestaurantList[position])
            fragment2.arguments = bundle
            ft.replace(R.id.restTabView, fragment2)
            ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
            ft.addToBackStack(null)
            ft.commit()
        }
    }

    override fun getItemCount(): Int {
        return mRestaurantList?.size ?: 0
    }

    class ViewHolder(val view: View) : RecyclerView.ViewHolder(view) {

        val restName: TextView
        val restCategory: TextView
        val restGoodFor: TextView
        val restOpenClose: TextView
        val imageDataView: ImageView

        init {
            restName = view.findViewById(R.id.restName)
            restCategory = view.findViewById(R.id.restCategory)
            restGoodFor = view.findViewById(R.id.restGoodFor)
            restOpenClose = view.findViewById(R.id.restOpenClose)
            imageDataView = view.findViewById(R.id.mImageView)
        }
    }
}