package com.example.codingtestcbre.utils

import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Date

object Utils {

    val BASE_URL = "http://dallas-restaurants.33gfuuywva.us-east-2.elasticbeanstalk.com/"
    val RESTAURANT_LIST_KEY = "RestaurantsList"
    val RESTAURANT_KEY = "Restaurant"

    fun isRestaurantOpen(openTime: String, closeTime: String): Boolean {
        try {
            //Displaying current time in 12 hour format with AM/PM
            val dateFormat = SimpleDateFormat("hhaa")

            val openDate = dateFormat.parse(openTime)
            val closeDate = dateFormat.parse(closeTime)
            val currentDate = dateFormat.parse(dateFormat.format(Date()))

            println("  openDate=$openDate closeDate=$closeDate  currentDate=$currentDate")

            if (currentDate!!.after(closeDate)) {
                //Restaurant closed
                return false
            }

            if (currentDate.after(openDate) && closeDate!!.after(currentDate)) {
                return true
            }

            if (openDate!!.before(currentDate) || closeDate!!.after(currentDate)
                || openDate.after(currentDate) || openDate == currentDate
            ) {
                return true
            }

        } catch (e: ParseException) {
            e.printStackTrace()
        }

        return false
    }
}
