package com.example.codingtestcbre.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction

import com.example.codingtestcbre.R
import com.example.codingtestcbre.model.RestaurantsModel
import com.example.codingtestcbre.utils.Utils
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

import java.util.ArrayList
import java.util.HashMap

class MapTabFragment : Fragment(), OnMapReadyCallback {

    private var mMap: GoogleMap? = null
    private var supportMapFragment: SupportMapFragment? = null
    internal var restaurantsList: ArrayList<RestaurantsModel>? = null
    private val markerMap = HashMap<LatLng, Int>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        restaurantsList = arguments!!.getSerializable(Utils.RESTAURANT_LIST_KEY) as ArrayList<RestaurantsModel>

        return inflater.inflate(R.layout.map_tab_fragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        val fm = activity!!.supportFragmentManager
        supportMapFragment = fm.findFragmentById(R.id.map_container) as SupportMapFragment?
        if (supportMapFragment == null) {
            supportMapFragment = SupportMapFragment.newInstance()
            fm.beginTransaction().replace(R.id.map_container, supportMapFragment!!).commit()
        }
        supportMapFragment!!.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        insertMarkers()
    }

    private fun insertMarkers() {

        for (i in restaurantsList!!.indices) {
            val position = LatLng(restaurantsList!![i].latitude!!, restaurantsList!![i].longitude!!)
            val options = MarkerOptions().position(position).title(restaurantsList!![i].name)
            markerMap[position] = i
            mMap!!.addMarker(options)

            mMap!!.moveCamera(CameraUpdateFactory.newLatLng(position))
        }
        //this is mandatory to display the map pins properly otherwise all of them overlap and showing as one map pin..
        mMap!!.animateCamera(CameraUpdateFactory.zoomTo(11.0f))
        mMap!!.setOnInfoWindowClickListener { marker ->
            val value = markerMap[marker.position]

            val fragment2 = RestaurantDetailsScreen()
            val ft = activity!!.supportFragmentManager.beginTransaction()
            val bundle = Bundle()
            bundle.putSerializable(Utils.RESTAURANT_KEY, restaurantsList!![value!!])
            fragment2.arguments = bundle
            ft.replace(R.id.map_container, fragment2)
            ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
            ft.addToBackStack(null)
            ft.commit()
        }
    }
}
