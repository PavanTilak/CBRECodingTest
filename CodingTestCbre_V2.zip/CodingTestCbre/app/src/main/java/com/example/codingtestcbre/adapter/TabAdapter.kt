package com.example.codingtestcbre.adapter

import android.content.Context
import android.graphics.PorterDuff

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter

import com.example.codingtestcbre.R

import java.util.ArrayList

class TabAdapter(fm: FragmentManager, private val context: Context, private val bundle: Bundle) :
    FragmentStatePagerAdapter(fm) {
    private val mFragmentList = ArrayList<Fragment>()
    private val mFragmentTitleList = ArrayList<String>()
    private val mFragmentIconList = ArrayList<Int>()

    override fun getItem(position: Int): Fragment {

        val fragment = mFragmentList[position]
        fragment.arguments = bundle

        return fragment
    }

    fun addFragment(fragment: Fragment, title: String, tabIcon: Int) {
        mFragmentList.add(fragment)
        mFragmentTitleList.add(title)
        mFragmentIconList.add(tabIcon)
    }

    override fun getPageTitle(position: Int): CharSequence? {
        //return mFragmentTitleList.get(position);
        return null
    }

    override fun getCount(): Int {
        return mFragmentList.size
    }

    fun getTabView(position: Int): View {
        val view = LayoutInflater.from(context).inflate(R.layout.custom_tab, null)
        val tabTextView = view.findViewById<TextView>(R.id.tabTextView)
        tabTextView.text = mFragmentTitleList[position]
        val tabImageView = view.findViewById<ImageView>(R.id.tabImageView)
        tabImageView.setImageResource(mFragmentIconList[position])
        return view
    }

    fun getSelectedTabView(position: Int): View {
        val view = LayoutInflater.from(context).inflate(R.layout.custom_tab, null)
        val tabTextView = view.findViewById<TextView>(R.id.tabTextView)
        tabTextView.text = mFragmentTitleList[position]
        tabTextView.setTextColor(ContextCompat.getColor(context, R.color.tab_selected))
        val tabImageView = view.findViewById<ImageView>(R.id.tabImageView)
        tabImageView.setImageResource(mFragmentIconList[position])
        tabImageView.setColorFilter(
            ContextCompat.getColor(context, R.color.tab_selected),
            PorterDuff.Mode.SRC_ATOP
        )
        return view
    }
}