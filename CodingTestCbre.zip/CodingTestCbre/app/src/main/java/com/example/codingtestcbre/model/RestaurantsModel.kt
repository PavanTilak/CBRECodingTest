package com.example.codingtestcbre.model

import java.io.Serializable

class RestaurantsModel(
        /**
         * "name": "Liberty Burger",
         * "postalCode": "75214",
         * "phoneNumber": "(214) 887-9999",
         * "state": "Texas",
         * "id": "b75862f1-d28a-11e9-b5c9-0a389e6da5d4",
         * "websiteUrl": "https://www.givemelibertyburger.com",
         * "description": "Local chain outpost supplying high-end burgers plus salads & sides in spare but stylish digs.",
         * "category": "Burgers",
         * "city": "Dallas",
         * "longitude": -96.752351,
         * "goodFor": "Comfort food,Outdoor seating,Quick bite",
         * "latitude": 32.813099,
         * "closeTime": "9PM",
         * "streetAddress": "1904 Abrams Pkwy",
         * "openTime": "11AM",
         * "imageUrl": "https://dallas-restaurants.s3.us-east-2.amazonaws.com/fd7b13a2-ce94-11e9-a32f-2a2ae2dbcce4.jpg"
         */
        var name: String, var postalCode: String, var phoneNumber: String, var state: String, var id: String, var websiteUrl: String,
        var description: String, var category: String, var city: String, var longitude: Double?, var goodFor: String, var latitude: Double?, var closeTime: String,
        var streetAddress: String, var openTime: String, var imageUrl: String) : Serializable
