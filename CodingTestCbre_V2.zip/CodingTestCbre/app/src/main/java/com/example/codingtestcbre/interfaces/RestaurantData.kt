package com.example.codingtestcbre.interfaces

import com.example.codingtestcbre.model.RestaurantsModel
import retrofit2.Call
import retrofit2.http.GET

interface RestaurantData {

    @get:GET("restaurants/")
    val restaurantsData: Call<List<RestaurantsModel>>
}
