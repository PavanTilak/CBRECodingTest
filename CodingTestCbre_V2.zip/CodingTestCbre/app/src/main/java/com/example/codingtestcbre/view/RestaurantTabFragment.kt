package com.example.codingtestcbre.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.example.codingtestcbre.R
import com.example.codingtestcbre.adapter.RestaurantsAdapter
import com.example.codingtestcbre.model.RestaurantsModel
import com.example.codingtestcbre.utils.Utils

import java.util.ArrayList

class RestaurantTabFragment : Fragment() {

    private var mRecyclerView: RecyclerView? = null
    internal var mLayoutManager: RecyclerView.LayoutManager? = null
    private var mRecyclerAdapter: RecyclerView.Adapter<*>? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val restaurantsList = arguments!!.getSerializable(Utils.RESTAURANT_LIST_KEY) as ArrayList<RestaurantsModel>
        mRecyclerAdapter = RestaurantsAdapter(restaurantsList, activity!!)

        val rootView = inflater.inflate(R.layout.restaurant_tab_fragment, container, false)
        mLayoutManager = LinearLayoutManager(activity)
        mRecyclerView = rootView.findViewById(R.id.recycler_view)
        mRecyclerView!!.layoutManager = mLayoutManager
        mRecyclerView!!.adapter = mRecyclerAdapter

        return rootView
    }
}
