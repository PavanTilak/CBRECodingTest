package com.example.codingtestcbre

import android.os.Bundle
import android.util.Log

import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.viewpager.widget.ViewPager

import com.example.codingtestcbre.adapter.TabAdapter
import com.example.codingtestcbre.interfaces.RestaurantData
import com.example.codingtestcbre.model.RestaurantsModel
import com.example.codingtestcbre.utils.Utils
import com.example.codingtestcbre.view.MapTabFragment
import com.example.codingtestcbre.view.RestaurantTabFragment
import com.google.android.material.tabs.TabLayout
import com.google.gson.GsonBuilder

import java.io.Serializable
import java.util.Collections

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity(), Callback<List<RestaurantsModel>> {

    private var mTabAdapter: TabAdapter? = null
    private var mTabLayout: TabLayout? = null
    private var mViewPager: ViewPager? = null
    private val tabIcons = intArrayOf(R.drawable.ic_restaurant, R.drawable.ic_map)
    private var mToolbar: Toolbar? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViewIds()

        backendApiCall()
    }

    private fun initViewIds() {
        mToolbar = findViewById(R.id.toolbar)
        setSupportActionBar(mToolbar)

        mViewPager = findViewById(R.id.viewPager)
        mTabLayout = findViewById(R.id.tabLayout)
        mViewPager!!.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}
            override fun onPageSelected(position: Int) {
                highLightCurrentTab(position)
            }

            override fun onPageScrollStateChanged(state: Int) {}
        })


    }

    private fun highLightCurrentTab(position: Int) {
        for (i in 0 until mTabLayout!!.tabCount) {
            val tab = mTabLayout!!.getTabAt(i)!!
            tab.customView = null
            tab.customView = mTabAdapter!!.getTabView(i)
        }
        val tab = mTabLayout!!.getTabAt(position)!!
        tab.customView = null
        tab.customView = mTabAdapter!!.getSelectedTabView(position)
    }

    private fun backendApiCall() {
        val gson = GsonBuilder()
            .setLenient()
            .create()

        val retrofit = Retrofit.Builder()
            .baseUrl(Utils.BASE_URL)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()

        val restaurantAPI = retrofit.create(RestaurantData::class.java)

        val call = restaurantAPI.restaurantsData
        call.enqueue(this)
    }

    override fun onResponse(call: Call<List<RestaurantsModel>>, response: Response<List<RestaurantsModel>>) {
        if (response.isSuccessful) {

            val restaurantsList = response.body()

            if (restaurantsList != null && restaurantsList.size > 0) {
                //Sort list items into alphabetical order..
                Collections.sort(restaurantsList) { modelObj1, modelObj2 ->
                    val s1 = modelObj1.name
                    val s2 = modelObj2.name
                    s1.compareTo(s2, ignoreCase = true)
                }

                //Create Bundle with Restaurant list...
                val bundle = Bundle()
                // putting questions list into the bundle .. as key value pair.
                // so you can retrieve the arrayList with this key
                bundle.putSerializable(Utils.RESTAURANT_LIST_KEY, restaurantsList as Serializable?)

                mTabAdapter = TabAdapter(supportFragmentManager, this, bundle)
                mTabAdapter!!.addFragment(RestaurantTabFragment(), resources.getString(R.string.tab1_text), tabIcons[0])
                mTabAdapter!!.addFragment(MapTabFragment(), resources.getString(R.string.tab2_text), tabIcons[1])

                mViewPager!!.adapter = mTabAdapter
                mTabLayout!!.setupWithViewPager(mViewPager)
                highLightCurrentTab(0)
            }

        } else {
            Log.e("MainActivity", "error response " + response.errorBody()!!)
        }
    }

    override fun onFailure(call: Call<List<RestaurantsModel>>, t: Throwable) {
        Log.e("MainActivity", "Failure in response ")
        t.printStackTrace()
    }


}