package com.example.codingtestcbre.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import com.example.codingtestcbre.MainActivity

import com.example.codingtestcbre.R
import com.example.codingtestcbre.model.RestaurantsModel
import com.example.codingtestcbre.utils.Utils
import com.squareup.picasso.Picasso

class RestaurantDetailsScreen : Fragment() {

    private var mImageView: ImageView? = null
    private var restDetailName: TextView? = null
    private var restDetailCategory: TextView? = null
    private var restDetailGoodfor: TextView? = null
    private var restDetailTime: TextView? = null
    private var restDetailDesc: TextView? = null
    private var restDetailAddress: TextView? = null
    private var restDetailState: TextView? = null
    private var restDetailPhone: TextView? = null
    private var toolbar: Toolbar? = null


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val rootView = inflater.inflate(R.layout.restaurant_details, container, false)

        toolbar = activity!!.findViewById(R.id.toolbar)

        (activity as MainActivity).supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        (activity as MainActivity).supportActionBar!!.setDisplayShowHomeEnabled(true)
        toolbar!!.setNavigationOnClickListener {
            // remove the back button
            (activity as MainActivity).supportActionBar!!.setDisplayHomeAsUpEnabled(false)
            (activity as MainActivity).supportActionBar!!.setDisplayShowHomeEnabled(false)
            activity!!.onBackPressed()
        }


        val bundle = arguments
        val restaurantsModel = bundle!!.getSerializable(Utils.RESTAURANT_KEY) as RestaurantsModel

        mImageView = rootView.findViewById(R.id.mImageView)
        Picasso.get().load(restaurantsModel.imageUrl).into(mImageView)

        restDetailName = rootView.findViewById(R.id.restDetailName)
        restDetailName!!.text = restaurantsModel.name

        restDetailCategory = rootView.findViewById(R.id.restDetailCategory)
        restDetailCategory!!.text = restaurantsModel.category

        restDetailGoodfor = rootView.findViewById(R.id.restDetailGoodfor)
        restDetailGoodfor!!.text = restaurantsModel.goodFor

        restDetailTime = rootView.findViewById(R.id.restDetailTime)
        restDetailTime!!.text = "Open " + restaurantsModel.openTime + " - " + restaurantsModel.closeTime

        restDetailDesc = rootView.findViewById(R.id.restDetailDesc)
        restDetailDesc!!.text = restaurantsModel.description

        restDetailAddress = rootView.findViewById(R.id.restDetailAddress)
        restDetailAddress!!.text = restaurantsModel.streetAddress

        restDetailState = rootView.findViewById(R.id.restDetailState)
        restDetailState!!.text = restaurantsModel.state + " " + restaurantsModel.postalCode

        restDetailPhone = rootView.findViewById(R.id.restDetailPhone)
        restDetailPhone!!.text = restaurantsModel.phoneNumber + ""

        return rootView
    }
}
